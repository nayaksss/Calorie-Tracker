//
//  CollectionViewCell.swift
//  UrbanFit
//
//  Created by Vinayak Balaji Tuptewar on 21/07/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var titlelbl: UILabel!
    @IBOutlet weak var imgview: UIImageView!
    @IBOutlet weak var totalCalLbl: UILabel!
    @IBOutlet weak var trackbtn: UIButton!
    @IBOutlet weak var trackBtnImage: UIButton!
    
}
