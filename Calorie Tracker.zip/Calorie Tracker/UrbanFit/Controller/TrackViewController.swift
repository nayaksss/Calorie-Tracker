//
//  TrackViewController.swift
//  UrbanFit
//
//  Created by Vinayak Balaji Tuptewar on 21/07/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit
import SQLite3

class TrackViewController: UIViewController {
    
    @IBOutlet weak var todaytf: UITextField!
    @IBOutlet weak var collectionView: UICollectionView!
    var toolBar = UIToolbar()
    var datepicker = UIDatePicker()
    static var currentDate = String()
    var collectionViewData = [CollectionModel]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadFunctionality()
    }
    
    
    
    override func viewWillAppear(_ animated: Bool){
        getTotalCaloriesFromDB()
    }
    
    
    
    @IBAction func track(_ sender: Any) {
        let calorieTrackerVC = self.storyboard?.instantiateViewController(identifier: "ctvc")as! CalorieTrackerViewController

        self.navigationController?.pushViewController(calorieTrackerVC, animated: true)
    }

    
    
    func loadFunctionality(){
        collectionViewData = [CollectionModel(title: "Calorie Tracker", Count: "\(CalorieTrackerViewController.totatCaloriesCount) of 2000 Cal eaten", image: #imageLiteral(resourceName: "kitchen")),CollectionModel(title: "Water Tracker", Count: "0 of 9 glasses consumed", image: #imageLiteral(resourceName: "water")),CollectionModel(title: "Workout Tracker", Count: "Not performed yet", image: #imageLiteral(resourceName: "fast")),CollectionModel(title: "Sleep Tracker", Count: "0 of 8h 0m slept", image: #imageLiteral(resourceName: "zzz"))]
        
        toolBar.sizeToFit()
        var donebtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(doneclick))
        toolBar.setItems([donebtn], animated: true)
        todaytf.inputAccessoryView = toolBar
        todaytf.inputView = datepicker
        
        datepicker.datePickerMode = .date
        let df = DateFormatter()
        df.dateStyle = .medium
        TrackViewController.currentDate = df.string(from: datepicker.date)
        print("current date = ",TrackViewController.currentDate)
    }
    
    
    @objc func doneclick(){
        datepicker.datePickerMode = .date
        let df = DateFormatter()
        df.dateStyle = .medium
        TrackViewController.currentDate = df.string(from: datepicker.date)
        todaytf.text = TrackViewController.currentDate
        print("current date = ",TrackViewController.currentDate)
        
        getTotalCaloriesFromDB()
        
        self.view.endEditing(true)
    }
    
    
    func getTotalCaloriesFromDB(){
        CalorieTrackerViewController.totatCaloriesCount = 0
        
        var url = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
        var dbpath = url.appendingPathComponent("UrbanFit4.sqlite")
        var ptr : OpaquePointer?
        var result : OpaquePointer?
        
        if sqlite3_open(dbpath.path, &ptr) == SQLITE_OK{
            let query = "SELECT * FROM SelectedItems WHERE date = '\(TrackViewController.currentDate)'"
            
            if sqlite3_prepare(ptr, query, -1, &result, nil) == SQLITE_OK{
                while sqlite3_step(result) == SQLITE_ROW{
                    
                    var t4 = sqlite3_column_double(result, 3)
                    
                    CalorieTrackerViewController.totatCaloriesCount += t4
                }
            }
            else{
                print("fail to read db")
            }
        }
        else{
            print("fail to open database")
        }
        sqlite3_close(ptr)
        
        collectionView.reloadData()
        
        collectionViewData = [CollectionModel(title: "Calorie Tracker", Count: "\(CalorieTrackerViewController.totatCaloriesCount) of 2000 Cal eaten", image: #imageLiteral(resourceName: "kitchen")),CollectionModel(title: "Water Tracker", Count: "0 of 9 glasses consumed", image: #imageLiteral(resourceName: "water")),CollectionModel(title: "Workout Tracker", Count: "Not performed yet", image: #imageLiteral(resourceName: "fast")),CollectionModel(title: "Sleep Tracker", Count: "0 of 8h 0m slept", image: #imageLiteral(resourceName: "zzz"))]
    }
    
}



extension TrackViewController:UICollectionViewDelegate,UICollectionViewDataSource{
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return collectionViewData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)as! CollectionViewCell
        cell.titlelbl.text = self.collectionViewData[indexPath.row].title
        cell.imgview.image = self.collectionViewData[indexPath.row].image
        cell.totalCalLbl.text = self.collectionViewData[indexPath.row].Count
        cell.trackbtn.tag = indexPath.row
        cell.trackBtnImage.tag = indexPath.row
        cell.trackbtn.addTarget(self, action: #selector(trackclick(sender:)), for: .touchUpInside)
        cell.trackBtnImage.addTarget(self, action: #selector(trackclick(sender:)), for: .touchUpInside)
        return cell
    }
    
    @objc func trackclick(sender: UIButton){
        
        switch sender.tag {
        case 0:
            let calorieTrackerVC = self.storyboard?.instantiateViewController(identifier: "ctvc")as! CalorieTrackerViewController
            
            self.navigationController?.pushViewController(calorieTrackerVC, animated: true)
        case 1:
            var alert = UIAlertController(title: "Water Tracker", message: "Cooming Soon", preferredStyle: .alert)
            var cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            alert.addAction(cancel)
            self.present(alert, animated: true, completion: nil)
            
        case 2:
            showAlert(title: "Workout Tracker", message: "Comming Soon")
        
        case 3:
            showAlert(title: "Sleep Tracker", message: "Comming Soon")
            
        default:
            print("Out of Index")
        }
        
    }
}



extension TrackViewController:UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        var collectionWidth = collectionView.bounds.width - 10
        var collectionHeight = collectionView.bounds.height - 10
        
        return CGSize(width: collectionWidth/2, height: collectionHeight/2)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {

        return 10
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        
        return 10
    }
}
