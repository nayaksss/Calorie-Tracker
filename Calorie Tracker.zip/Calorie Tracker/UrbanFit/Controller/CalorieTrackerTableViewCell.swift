//
//  CalorieTrackerTableViewCell.swift
//  UrbanFit
//
//  Created by Vinayak Balaji Tuptewar on 22/07/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit

class CalorieTrackerTableViewCell: UITableViewCell {
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var plusBtn: UIButton!
    @IBOutlet weak var imgView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        plusBtn.layer.cornerRadius = plusBtn.frame.size.width / 2
        plusBtn.clipsToBounds = true
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
