//
//  ListViewController.swift
//  UrbanFit
//
//  Created by Vinayak Balaji Tuptewar on 22/07/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit
import SQLite3

class ListViewController: UIViewController {
    @IBOutlet weak var tableview: UITableView!
    var arrData = [Data]()
    var selectedCat = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
    }
    
    
    
    func getData(){
        let url = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
        let dbpath = url.appendingPathComponent("UrbanFit4.sqlite")
        var ptr : OpaquePointer?
        var result : OpaquePointer?
        
        if sqlite3_open(dbpath.path, &ptr) == SQLITE_OK{
            
            let query = "select * from DishItems"
            
            if sqlite3_prepare(ptr, query, -1, &result, nil) == SQLITE_OK{
                while sqlite3_step(result) == SQLITE_ROW{
                    var t1 = sqlite3_column_int(result, 0)
                    var t2 = String.init(format: "%s", sqlite3_column_text(result, 1))
                    var t3 = sqlite3_column_double(result, 2)
                    var t4 = sqlite3_column_double(result, 3)
                    var t5 = sqlite3_column_double(result, 4)
                    var t6 = sqlite3_column_double(result, 5)
                    var t7 = sqlite3_column_double(result, 6)
                    var t8 = String(format: "%s", sqlite3_column_text(result, 7))
                    
                    print("list view controller ",t1,t2,t3,t4,t5,t6,t7,t8)
                    arrData.append(Data(id: Int(t1), name: t2, calories: t3, proteins: t4, carbs: t5, fats: t6, fibers: t7, imageString: t8))
                    
                    tableview.reloadData()
                }
            }
            sqlite3_close(ptr)
        }
    }
}




extension ListViewController:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrData.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")as! ListTableViewCell
        
        cell.label.text = self.arrData[indexPath.row].name
        cell.plusButton.addTarget(self, action: #selector(plusButtonClicked(sender:)), for: .touchUpInside)
        cell.plusButton.tag = indexPath.row
        cell.imgview.image = UIImage(imageLiteralResourceName: "\(self.arrData[indexPath.row].imageString)")
        return cell
    }
    
    
    @objc func plusButtonClicked(sender: UIButton){
        var detailVC = self.storyboard?.instantiateViewController(identifier: "dvc")as! DetailViewController
        detailVC.data = self.arrData[sender.tag]
        detailVC.tempSelectedCategory = selectedCat
        
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        var detailVC = self.storyboard?.instantiateViewController(identifier: "dvc")as! DetailViewController
        detailVC.data = self.arrData[indexPath.row]
        detailVC.tempSelectedCategory = selectedCat
        
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
     
}
