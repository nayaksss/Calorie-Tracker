//
//  CalorieTrackerViewController.swift
//  UrbanFit
//
//  Created by Vinayak Balaji Tuptewar on 21/07/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.

import UIKit
import SQLite3

class CalorieTrackerViewController: UIViewController {
    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var totallbl: UILabel!
    
    static var tableViewData = [CellData]()
    var senderTag = Int()
    static var totatCaloriesCount = Double()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        CalorieTrackerViewController.tableViewData = [
            CellData(opened: false, title: "Breakfast", image: #imageLiteral(resourceName: "chole-bhature"), sectionData: [],imageNameArray: []),
            CellData(opened: false, title: "Morning Snack", image: #imageLiteral(resourceName: "dhansak"), sectionData: [],imageNameArray: []),
            CellData(opened: false, title: "Lunch", image: #imageLiteral(resourceName: "rogan-josh"), sectionData: [],imageNameArray: []),
            CellData(opened: false, title: "Evening Snack", image: #imageLiteral(resourceName: "chaat"), sectionData: [],imageNameArray: []),
            CellData(opened: false, title: "Dinner", image: #imageLiteral(resourceName: "tandoori"), sectionData: [],imageNameArray: [])
        ]
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getData()
        totallbl.text = "\(CalorieTrackerViewController.totatCaloriesCount) of 2000.0 Cal eaten"
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
    }
    
    
    
    
    func getData(){
        CalorieTrackerViewController.totatCaloriesCount = 0.0
        for index in 0..<CalorieTrackerViewController.tableViewData.count{
            CalorieTrackerViewController.tableViewData[index].sectionData.removeAll()
            CalorieTrackerViewController.tableViewData[index].imageNameArray.removeAll()
        }
        
        var url = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
        var dbpath = url.appendingPathComponent("UrbanFit4.sqlite")
        var ptr : OpaquePointer?
        var result : OpaquePointer?
        
        if sqlite3_open(dbpath.path, &ptr) == SQLITE_OK{
            let query = "SELECT * FROM SelectedItems WHERE date = '\(TrackViewController.currentDate)'"
            
            if sqlite3_prepare(ptr, query, -1, &result, nil) == SQLITE_OK{
                while sqlite3_step(result) == SQLITE_ROW{
                    
                    var t2 = String.init(format: "%s", sqlite3_column_text(result, 1))
                    var t3 = String.init(format: "%s", sqlite3_column_text(result, 2))
                    var t4 = sqlite3_column_double(result, 3)
                    var t10 = String(format: "%s", sqlite3_column_text(result, 9))
                        
                    CalorieTrackerViewController.totatCaloriesCount += t4
                    
                    for index in 0..<CalorieTrackerViewController.tableViewData.count{
                        if CalorieTrackerViewController.tableViewData[index].title == t2{
                            CalorieTrackerViewController.tableViewData[index].sectionData.append(t3)
                            CalorieTrackerViewController.tableViewData[index].imageNameArray.append(t10)
                        }
                    }
                }
            }
            else{
                print("No data in database OR Fail to read database")
            }
        }
        else{
            print("fail to open database")
        }
        sqlite3_close(ptr)
        
        tableview.reloadData()
    }
    
}



extension CalorieTrackerViewController:UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return CalorieTrackerViewController.tableViewData.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if CalorieTrackerViewController.tableViewData[section].opened == true{
            return CalorieTrackerViewController.tableViewData[section].sectionData.count + 1
        }else{
            return 1
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell")as? CalorieTrackerTableViewCell
            cell!.label.text = CalorieTrackerViewController.tableViewData[indexPath.section].title
            
            cell!.plusBtn.isHidden = false
            cell!.plusBtn.addTarget(self, action: #selector(plusclicked(sender:)), for: .touchUpInside)
            cell!.plusBtn.tag = indexPath.section
            cell!.imgView.image = CalorieTrackerViewController.tableViewData[indexPath.section].image
            
            return cell!
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell2")as? CalorieTrackerTableViewCell
            cell!.label?.text = CalorieTrackerViewController.tableViewData[indexPath.section].sectionData[indexPath.row - 1]
            cell!.imgView.image = UIImage(imageLiteralResourceName: "\(CalorieTrackerViewController.tableViewData[indexPath.section].imageNameArray[indexPath.row - 1])")
            cell!.plusBtn.isHidden = true
            return cell!
        }
    }
    
    
    @objc func plusclicked(sender:UIButton){
        let listVC = self.storyboard?.instantiateViewController(identifier: "lvc")as! ListViewController
        
        listVC.selectedCat = CalorieTrackerViewController.tableViewData[sender.tag].title
        
        self.navigationController?.pushViewController(listVC, animated: true)
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if CalorieTrackerViewController.tableViewData[indexPath.section].opened == true{
            CalorieTrackerViewController.tableViewData[indexPath.section].opened = false
            
            var sections = IndexSet.init(integer: indexPath.section)
            tableView.reloadSections(sections, with: .none)

        }else{
            CalorieTrackerViewController.tableViewData[indexPath.section].opened = true
            
            var sections = IndexSet.init(integer: indexPath.section)
            tableView.reloadSections(sections, with: .none)
            }
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}

