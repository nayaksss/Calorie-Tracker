//
//  DetailViewController.swift
//  UrbanFit
//
//  Created by Vinayak Balaji Tuptewar on 22/07/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import UIKit
import SQLite3

class DetailViewController: UIViewController {
    var data:Data?
    var tempSelectedCategory = ""
    
    @IBOutlet weak var foodNamelbl: UILabel!
    @IBOutlet weak var proteinslbl: UILabel!
    @IBOutlet weak var fatslbl: UILabel!
    @IBOutlet weak var fiberlbl: UILabel!
    @IBOutlet weak var carbslbl: UILabel!
    @IBOutlet weak var donebtn: UIButton!
    @IBOutlet weak var imageview: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        foodNamelbl.text = data!.name
        proteinslbl.text = "\(data!.proteins) g"
        carbslbl.text = "\(data!.carbs) g"
        fatslbl.text = "\(data!.fats) g"
        fiberlbl.text = "\(data!.fibers) g"
        imageview.image = UIImage(imageLiteralResourceName: "\(data!.imageString)")
    
        donebtn.layer.cornerRadius = donebtn.frame.size.height / 2
        donebtn.clipsToBounds = true
    }
    
    
    @IBAction func doneClick(_ sender: Any) {
        let url = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
        var dbpath = url.appendingPathComponent("UrbanFit4.sqlite")
        var filemanager = FileManager()
        var ptr:OpaquePointer?
        
        if sqlite3_open(dbpath.path, &ptr) == SQLITE_OK{
            
            let query = String(format: "insert into SelectedItems values(%d,'%@','%@',%f,%f,%f,%f,%f,'%@','%@')", 1,"\(tempSelectedCategory)","\(data!.name)",data!.calories,data!.proteins,data!.carbs,data!.fats,data!.fibers,"\(TrackViewController.currentDate)","\(data!.imageString)")
            print(query)
            if sqlite3_exec(ptr, query, nil, nil, nil) == SQLITE_OK{
                print("successfully Inserted")
                
            }else{
                print("fail to insert into table")
            }
            sqlite3_close(ptr)
        }else{
            print("fail to open database")
        }
        
        self.navigationController?.popViewController(animated: true)
    }
   
}
