//  AppDelegate.swift
//  UrbanFit
//
//  Created by Vinayak Balaji Tuptewar on 21/07/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.

import UIKit
import SQLite3

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        createSqliteDatabase()
        return true
    }
    
    
//    MARK: Creating Sqlite database Function
    func createSqliteDatabase(){
            let url = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            var dbpath = url.appendingPathComponent("UrbanFit4.sqlite")
            var filemanager = FileManager()
            var ptr:OpaquePointer?
            print(dbpath)
                
            if filemanager.fileExists(atPath: dbpath.path){
                print("database already present")
            }else{
                if sqlite3_open(dbpath.path, &ptr) == SQLITE_OK{
                let query = "create table DishItems (id integer ,name varchar(20),  calories double, proteins double, carbs double, fats double, fibers double,imagename varchar(20));insert into DishItems values(1,'Roti',85,3,17.4,0.4,2.7,'roti1');insert into DishItems values(2,'Nan',149,3.7,22.9,4.6,1.3,'nan1');insert into DishItems values(3,'Mutter Paneer',137,6.2,11,7.8,4.6,'matterPaneer1');insert into DishItems values(4,'Masur Dal',127,7.7,18.4,2.1,3.6,'masoorDal1');create table SelectedItems (id integer ,categoryName varchar(20), dishItemName varchar(20), calories double, proteins double, carbs double, fats double, fibers double, date varchar(20), imageString varchar(20))"
                                        
                   if sqlite3_exec(ptr, query, nil, nil, nil) == SQLITE_OK{
                        print("Created table DishItems, Category, SelectedItems and inserted appropriate data in it.")
                        print(query)
                    }else{
                        print("fail to create tables")
                    }
                }else{
                    print("fail to open database")
                }
                sqlite3_close(ptr)
            }
        }
    
    

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }


}

