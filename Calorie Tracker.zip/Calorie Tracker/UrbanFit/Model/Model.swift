//
//  Model.swift
//  UrbanFit
//
//  Created by swapnil jadhav on 23/07/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import Foundation
import UIKit


//MARK: This Struct Is Used in ListViewController
struct Data {
    var id = 0
    var name = ""
    var calories = 0.0
    var proteins = 0.0
    var carbs = 0.0
    var fats = 0.0
    var fibers = 0.0
    var imageString = ""
    init(id:Int,name:String,calories:Double,proteins:Double,carbs:Double,fats:Double,fibers:Double,imageString:String) {
        
        self.id = id
        self.name = name
        self.calories = calories
        self.proteins = proteins
        self.carbs = carbs
        self.fats = fats
        self.fibers = fibers
        self.imageString = imageString
    }

}



//MARK: This Struct Is Used in TravkerViewController
struct CollectionModel{
    var title = String()
    var Count = String()
    var image = UIImage()
}


//MARK: This Struct Is Used in CalrieTravkerViewController
struct CellData{
    var opened = Bool()
    var title = String()
    var image = UIImage()
    var sectionData = [String]()
    var imageNameArray = [String]()
    
}



//MARK: This Function is used for creating alert view.
extension UIViewController{
    func showAlert(title:String,message:String){
        var alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        var cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(cancel)
        self.present(alert, animated: true, completion: nil)
    }
}
